//
// Created by hubert on 07.05.19.
//

#ifndef LAB08_MAIN_H
#define LAB08_MAIN_H

#include "LicznikPoziomow.h"
#include "Calc_error.h"

#endif //LAB08_MAIN_H
