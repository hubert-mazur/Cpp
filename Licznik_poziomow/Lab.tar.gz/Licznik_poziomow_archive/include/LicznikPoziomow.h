//
// Created by hubert on 07.05.19.
//

#ifndef LAB08_LICZNIKPOZIOMOW_H
#define LAB08_LICZNIKPOZIOMOW_H


class LicznikPoziomow
{

public:
	LicznikPoziomow ();
	~LicznikPoziomow ();

protected:
	static unsigned licznik;

};


#endif //LAB08_LICZNIKPOZIOMOW_H
