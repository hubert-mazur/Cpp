#pragma once
#include "Motorower.h"

class Romet : public Motorower
{
  public:
    Romet(Silnik object, float stan_licznika = 0) : Motorower(object, "czerwony metalic", stan_licznika){};
    Romet() : Motorower(){};
};