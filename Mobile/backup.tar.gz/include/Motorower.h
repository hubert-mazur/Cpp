#pragma once
#include "Pojazd.h"

class Motorower : public Pojazd
{
  public:
      Motorower(Silnik object, std::string kolor, float stan_licznika = 0) : Pojazd(object, stan_licznika)
    {
        _kola = 2;
        _kolor = kolor;
    };
    Motorower(Silnik object, float stan_licznika = 0) : Pojazd(object, stan_licznika)
    {
        _kola = 2;
        _kolor = "czarny";
    };
    Motorower() : Pojazd()
    {
    }
    int get_liczbe_kol()
    {
        return _kola;
    }
    float get_stan_licznika()
    {
        return _stan_licznika;
    }
    std::string &get_kolor()
    {
        return _kolor;
    }
      protected:
    int _kola;
    std::string _kolor;
};