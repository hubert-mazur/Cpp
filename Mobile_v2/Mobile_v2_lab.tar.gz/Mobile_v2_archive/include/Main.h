#pragma once
#include "Silnik.h"
#include "Samochod.h"
#include "Mercedes.h"
#include "Motorower.h"
#include "Romet.h"