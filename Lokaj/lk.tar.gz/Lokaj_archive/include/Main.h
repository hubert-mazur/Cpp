//
// Created by hubert on 09.05.19.
//

#ifndef LAB08_MAIN_H
#define LAB08_MAIN_H

#include "Pomieszczenie.h"
#include "Lokaj.h"

#endif //LAB08_MAIN_H
