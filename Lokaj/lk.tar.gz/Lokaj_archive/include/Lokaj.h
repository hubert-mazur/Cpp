//
// Created by hubert on 09.05.19.
//

#ifndef LAB08_LOKAJ_H
#define LAB08_LOKAJ_H

#include "Pomieszczenie.h"

template <typename T>
class Lokaj {

public:

	explicit Lokaj (const Pomieszczenie &obj);

protected:
	Pomieszczenie object;

};





#endif //LAB08_LOKAJ_H
