//
// Created by hubert on 15.05.19.
//

#ifndef LAB08_MAIN_H
#define LAB08_MAIN_H

#include "Object.h"
#include "UniquePointer.h"

#endif //LAB08_MAIN_H
